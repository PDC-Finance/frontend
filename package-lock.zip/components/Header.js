import headerStyles from '../styles/Header.module.css'

import React from 'react';

const Header = () => {
    return (
        <div>
            <h1>
                
            </h1>
        </div>
    );
};

export default Header;