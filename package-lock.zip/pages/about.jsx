import Meta from '../components/Meta'

const about = () => {
    return (
        <div>
            

            <Meta title='About' />
            <link rel="icon" href="/favicon.png" />
            <h1>About</h1>
        </div>
    )
}

export default about